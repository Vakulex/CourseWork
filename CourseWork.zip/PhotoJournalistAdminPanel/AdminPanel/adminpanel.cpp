#include "AdminPanel/adminpanel.h"
#include "QModelIndex"
#include "QAbstractItemModel"
#include "QDebug"

AdminPanel::AdminPanel(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AdminPanel)
{
    ui->setupUi(this);

    DatabaseManager::GetInstance()->ConnectToDatabase();
    model = new QSqlTableModel();
    createUserModel(model);
    WidgetSettings();
    initResources();
}

AdminPanel::~AdminPanel()
{
    delete ui;
}

void AdminPanel::initResources()
{
    ui->AddButton->setIcon(QIcon(":/icons/img/b_plus_icon.png"));
    ui->DeleteButton->setIcon(QIcon(":/icons/img/b_minus_icon.png"));
    ui->UpdateButton->setIcon(QIcon(":/icons/img/b_refresh_icon.png"));

    ui->OptionsMenu->setIcon(QIcon(":/icons/img/b_gear_icon.png"));
    ui->ProfileAction->setIcon(QIcon(":/icons/img/b_user_icon.png"));
    ui->OptionsAction->setIcon(QIcon(":/icons/img/b_gear_icon.png"));
}

void AdminPanel::createUserModel(QSqlTableModel *model)
{
    model->setTable("users");
    model->select();

    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("Прізвище"));
    model->setHeaderData(2, Qt::Horizontal, tr("Ім'я"));
    model->setHeaderData(3, Qt::Horizontal, tr("По-батькові"));
    model->setHeaderData(4, Qt::Horizontal, tr("Номер телефону"));

    ui->UsersTable->setModel(model);
}

void AdminPanel::WidgetSettings()
{
    ui->UsersTable->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->UsersTable->horizontalHeader()->setStretchLastSection(true);
}

void AdminPanel::on_AddButton_clicked()
{
    AddUserData *window = new AddUserData;
    window->show();
    if(window->isHidden())
        model->select();
}

void AdminPanel::on_AddService_triggered()
{
    AddService *window = new AddService();
    window->show();
}

void AdminPanel::on_DBOptionsAction_triggered()
{
    DataBaseOptions *window = new DataBaseOptions();
    window->show();
}

void AdminPanel::on_DeleteButton_clicked()
{
    QSqlQuery query;
    QModelIndex index;
    if(QMessageBox::question(this, "Видалення об'єкту", "Ви впевнені, що хочете видалити обраного користувача?",
                                        QMessageBox::Yes|QMessageBox::No) == QMessageBox::Yes)
    {
        index = ui->UsersTable->selectionModel()->currentIndex();
        QVariant value = index.sibling(index.row(), 0).data();
        query.prepare("Delete from users where users_ID=" + value.toString());
        query.exec();
    }

    model->select();
}

void AdminPanel::on_UpdateButton_clicked()
{
    model->select();
}

void AdminPanel::on_DeleteService_triggered()
{
    DeleteServices *window = new DeleteServices();
    window->show();
}

void AdminPanel::on_UsersTable_clicked(const QModelIndex &index)
{
    QSqlQuery query;
    query.prepare("select * from order_data INNER JOIN services ON order_data.service_ID = services.service_ID where users_ID = " + ui->UsersTable->model()->index(index.row(),0).data().toString());
    query.exec();
    query.next();
    QSqlRecord record = query.record();
    ui->StartDate->setDate(QDate::fromString(record.value("creation_date").toString(), "yyyy-MM-dd"));
    ui->ServiceComboBox->setCurrentText(record.value("name_service").toString());
    ui->AdressLineEdit->setText(record.value("adress").toString());
    ui->PriceLineEdit->setText(record.value("order_price").toString());
    ui->statusCheckBox->setChecked(record.value("order_status").toBool());

    if(ui->statusCheckBox->isChecked())
    {
        ui->EndDate->setEnabled(true);
        ui->PhotoPathLineEdit->setEnabled(true);
        ui->EndDate->setDate(QDate::fromString(record.value("finalization_date").toString(), "yyyy-MM-dd"));
        ui->PhotoPathLineEdit->setText(record.value("img").toString());
    }
    else
    {
        ui->EndDate->setEnabled(false);
        ui->PhotoPathLineEdit->setEnabled(false);
    }
}
